const Users = require("../users/users-model");

function logger(req, res, next) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} to ${req.originalUrl}`);
  next();
}

async function validateUserId(req, res, next) {
  try {
    const { id } = req.params;
    const user = await Users.getById(id);
    if (!user) {
      return res.status(404).json({ message: "user not found" });
    }
    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}

function validateUser(req, res, next) {
  if (!req.body || !req.body.name) {
    return res.status(400).json({ message: "gerekli name alanı eksik" });
  }
  next();
}

function validatePost(req, res, next) {
  if (!req.body || !req.body.text) {
    return res.status(400).json({ message: "gerekli text alanı eksik" });
  }
  next();
}

module.exports = {
  logger,
  validateUserId,
  validateUser,
  validatePost,
};
