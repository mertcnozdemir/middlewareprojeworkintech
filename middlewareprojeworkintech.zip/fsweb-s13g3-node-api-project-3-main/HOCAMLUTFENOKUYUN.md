Sayın hocam kodu tamamladım ancak test ettiremedim *knex* hatası verdi sanırım node_modules kurulmadığından veya bilgisayarım görmediği için.

Projeyi bu haliyle teslim ediyorum eğer bana node_modules'ü kendin oluştur derseniz düzenlerim. Teşekkürler