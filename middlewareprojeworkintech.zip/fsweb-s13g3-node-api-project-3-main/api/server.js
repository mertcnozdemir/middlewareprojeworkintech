const express = require('express');
const usersRouter = require('./users/users-router');
const { logger } = require('./middleware/middleware');

const server = express();

server.use(express.json());
server.use(logger);

server.use('/api/users', usersRouter);

server.get('/', (req, res) => {
  res.send(`<h2>Biraz ara yazılım yazalım!</h2>`);
});

server.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Beklenmeyen bir hata oluştu" });
});

module.exports = server;
