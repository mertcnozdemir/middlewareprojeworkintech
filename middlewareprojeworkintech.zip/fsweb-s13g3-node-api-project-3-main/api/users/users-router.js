const express = require('express');
const Users = require('./users-model');
const Posts = require('../posts/posts-model');
const { validateUserId, validateUser, validatePost } = require('../middleware/middleware');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const users = await Users.get();
    res.json(users);
  } catch (err) {
    next(err);
  }
});

router.get('/:id', validateUserId, (req, res) => {
  res.json(req.user);
});

router.post('/', validateUser, async (req, res, next) => {
  try {
    const newUser = await Users.insert({ name: req.body.name });
    res.status(201).json(newUser);
  } catch (err) {
    next(err);
  }
});

router.put('/:id', validateUserId, validateUser, async (req, res, next) => {
  try {
    const updated = await Users.update(req.params.id, { name: req.body.name });
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', validateUserId, async (req, res, next) => {
  try {
    const user = req.user;
    await Users.remove(req.params.id);
    res.json(user);
  } catch (err) {
    next(err);
  }
});

router.get('/:id/posts', validateUserId, async (req, res, next) => {
  try {
    const posts = await Users.getUserPosts(req.params.id);
    res.json(posts);
  } catch (err) {
    next(err);
  }
});

router.post('/:id/posts', validateUserId, validatePost, async (req, res, next) => {
  try {
    const postInfo = { ...req.body, user_id: req.params.id };
    const newPost = await Posts.insert(postInfo);
    res.status(201).json(newPost);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
